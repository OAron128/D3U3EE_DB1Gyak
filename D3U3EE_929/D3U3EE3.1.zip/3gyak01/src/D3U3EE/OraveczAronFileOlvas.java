package D3U3EE;


import java.io.*;
import java.util.Scanner;

public class OraveczAronFileOlvas {

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Olvassuk be az adatokat");
		int olvas = sc.nextInt();
		
		read_text_(olvas);
		
		sc.close();
		
	}

	private static void read_text_(int olvas) {
		String fnev="Oravecz.txt";
		int db=0;
		int szam;
		int sum=0;
		int i=0;
		try {
		      File myObj = new File(fnev);
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()&& db<olvas) {
		        szam=myReader.nextInt();
		        
		        db++;
		        i++;
		        sum=szam+sum;
		        System.out.println(i+"."+"Adat:"+szam);
		       
		      }
		      System.out.println("db:"+db);
		      System.out.println("�sszeg:"+sum);
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		
	}



}
